-- Project 3: SQL Data Analysis
-- DecodeLabs Data Analytics Track
-- Table: orders (loaded from Dataset_for_Data_Analytics.xlsx)

-- q1_select_basic
SELECT OrderID, Date, Product, Quantity, TotalPrice
FROM orders
LIMIT 10;

-- q2_where_filter
SELECT OrderID, Product, TotalPrice, OrderStatus
FROM orders
WHERE OrderStatus = 'Delivered'
LIMIT 10;

-- q3_where_comparison
SELECT OrderID, Product, TotalPrice
FROM orders
WHERE TotalPrice > 2000
LIMIT 10;

-- q4_orderby
SELECT OrderID, Product, TotalPrice
FROM orders
ORDER BY TotalPrice DESC
LIMIT 10;

-- q5_groupby_count
SELECT Product, COUNT(*) AS TotalOrders
FROM orders
GROUP BY Product
ORDER BY TotalOrders DESC;

-- q6_groupby_sum
SELECT Product, SUM(TotalPrice) AS TotalRevenue
FROM orders
GROUP BY Product
ORDER BY TotalRevenue DESC;

-- q7_groupby_avg
SELECT PaymentMethod, ROUND(AVG(TotalPrice),2) AS AvgOrderValue
FROM orders
GROUP BY PaymentMethod
ORDER BY AvgOrderValue DESC;

-- q8_multi_condition_where
SELECT OrderID, Product, PaymentMethod, TotalPrice
FROM orders
WHERE PaymentMethod = 'Credit Card' AND TotalPrice > 1000
ORDER BY TotalPrice DESC
LIMIT 10;

-- q9_status_breakdown
SELECT OrderStatus, COUNT(*) AS OrderCount,
       ROUND(SUM(TotalPrice),2) AS TotalRevenue
FROM orders
GROUP BY OrderStatus
ORDER BY OrderCount DESC;

-- q10_referral_performance
SELECT ReferralSource, COUNT(*) AS Orders,
       ROUND(SUM(TotalPrice),2) AS Revenue,
       ROUND(AVG(TotalPrice),2) AS AvgOrderValue
FROM orders
GROUP BY ReferralSource
ORDER BY Revenue DESC;

-- q11_having_bonus
SELECT Product, COUNT(*) AS OrdersCount, ROUND(SUM(TotalPrice),2) AS Revenue
FROM orders
GROUP BY Product
HAVING SUM(TotalPrice) > 150000
ORDER BY Revenue DESC;

-- q12_percentage_contribution
SELECT Product,
       ROUND(SUM(TotalPrice),2) AS Revenue,
       ROUND(100.0 * SUM(TotalPrice) / (SELECT SUM(TotalPrice) FROM orders), 2) AS PctOfTotalRevenue
FROM orders
GROUP BY Product
ORDER BY Revenue DESC;

-- q13_coupon_usage
SELECT COALESCE(CouponCode, 'No Coupon') AS Coupon,
       COUNT(*) AS OrdersCount,
       ROUND(AVG(TotalPrice),2) AS AvgOrderValue
FROM orders
GROUP BY Coupon
ORDER BY OrdersCount DESC;

-- q14_top_customers
SELECT CustomerID, COUNT(*) AS OrdersPlaced, ROUND(SUM(TotalPrice),2) AS TotalSpent
FROM orders
GROUP BY CustomerID
ORDER BY TotalSpent DESC
LIMIT 10;

